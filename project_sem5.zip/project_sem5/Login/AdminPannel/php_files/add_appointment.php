<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="website icon" href="../images/logo.png" />
    <link rel="stylesheet" href="../styles/add_appointmentcss.css" type="text/css">
    <script>
        function validateAppointment() {
            var patient = document.getElementById("patient").value;
            var doctor = document.getElementById("doctor").value;
            var apoint_date = document.getElementById("apoint_date").value;
            var apoint_time = document.getElementById("apoint_time").value;
            var reason = document.getElementById("reason").value;

            if (!patient) {
                document.getElementById("pval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("pval").style.display = "none";
                }, 1200);

                return false;
            } else if (!doctor) {
                document.getElementById("dval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("dval").style.display = "none";
                }, 1200);

                return false;
            } else if (!apoint_date) {
                document.getElementById("dtval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("dtval").style.display = "none";
                }, 1200);

                return false;
            } else if (!apoint_time) {
                document.getElementById("tval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("tval").style.display = "none";
                }, 1200);

                return false;
            } else if (!reason) {
                document.getElementById("rval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("rval").style.display = "none";
                }, 1200);

                return false;
            } else {
                return true;
            }
        }
    </script>
</head>

<body>
    <?php
    include_once("databaseconnect.php");

    $conn = connection();

    if (!$conn) {
        echo "ERROR!!!";
    } else {
        session_start();
        if (!isset($_SESSION['admin'])) {
            header("Location:../../Login.php");
        }

        $fetch_doctors = "SELECT * from doctors WHERE `status`='Active'";
        $doctors_record = mysqli_query($conn, $fetch_doctors);
        $patient_rec = mysqli_query($conn, "SELECT * FROM patients");

        if (isset($_REQUEST["btn_bookappointment"])) {
            $pname = $_REQUEST["patient"];
            $doctor = $_REQUEST["doctor"];
            $date = $_REQUEST["apoint_date"];
            $time = $_REQUEST["apoint_time"];
            $reason = $_REQUEST["reason"];

            $Q = "INSERT INTO appointment(patient_id,doctor_id,`date`,`time`,reason) VALUES($pname,$doctor,'$date','$time','$reason')";
            $result = $conn->query($Q);

            if ($result) {
                header("Location:appointment.php");
            } else {
    ?>
                <script>
                    alert("Appointment Not Booked...");
                </script>
    <?php
            }
        }

        $patient_id = "";
        $doctor_id = "";
        $date = "";
        $time = "";
        $reason = "";


        if (isset($_REQUEST["update_id"])) {
            $update_id = $_REQUEST["update_id"];
            $query = "SELECT * FROM appointment WHERE appoint_id=$update_id";
            $fetch_appointmnet = mysqli_query($conn, $query);
            $data = mysqli_fetch_assoc($fetch_appointmnet);

            $patient_id = $data["patient_id"];
            $doctor_id = $data["doctor_id"];
            $date = $data["date"];
            $time = $data["time"];
            $reason = $data["reason"];
        }

        if (isset($_REQUEST["btn_update"])) {
            $upid = $_REQUEST["update_id"];

            $pname = $_REQUEST["patient"];
            $doctor = $_REQUEST["doctor"];
            $date = $_REQUEST["apoint_date"];
            $time = $_REQUEST["apoint_time"];
            $reason = $_REQUEST["reason"];

            $q = "UPDATE appointment SET patient_id=$pname , doctor_id=$doctor , `date`='$date' , `time`='$time',
            reason='$reason' WHERE appoint_id=$upid";
            mysqli_query($conn, $q);
            // echo $q;
        }
    }
    ?>

    <div class="maincontainer">
        <div class="navbar">
            <?php include_once("navbar.php") ?>
        </div>

        <div class="content">

            <div class="patientform" id="patientform">

                <div class="heading2">
                    <h3 class="field_heading text-danger">Add New Appointment </h3>
                    <a href="appointment.php"><button class="btn btn-outline-primary">Back</button></a>
                </div>

                <form method="post" class="form" onsubmit="return validateAppointment()">

                    <div class='form-floating mb-4'>
                        <select name="patient" id="patient" class="form-select">
                            <option value="">Select Patient</option>
                            <?php
                            while ($patient = $patient_rec->fetch_assoc()) {
                            ?>
                                <option value="<?php echo $patient["patient_id"] ?>" <?php if ($patient_id == $patient["patient_id"]) { ?> selected <?php } ?>><?php echo $patient["patient_name"] ?></option>
                            <?php
                            }
                            ?>
                        </select>
                        <label>Patients</label>
                        <span id="pval" style="color:red;display:none;"> * Select Patients </span>
                    </div>

                    <div class='form-floating mb-4'>
                        <select name="doctor" id="doctor" class="form-select">
                            <option value="">Select doctor</option>
                            <?php
                            while ($doctors = $doctors_record->fetch_assoc()) {
                            ?>
                                <option value="<?php echo $doctors["doctor_id"] ?>" <?php if ($doctor_id == $doctors["doctor_id"]) { ?> selected <?php } ?>><?php echo $doctors["doctor_name"] ?></option>
                            <?php
                            }
                            ?>
                        </select>
                        <label>Doctors</label>
                        <span id="dval" style="color:red;display:none;"> * Select Doctors </span>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type="date" class='form-control' placeholder='' autocomplete="off" id="apoint_date" name="apoint_date" value="<?php echo $date ?>" />
                        <label>Appointment Date</label>
                        <span id="dtval" style="color:red;display:none;"> * Required </span>
                    </div>

                    <div class='form-floating mb-4'>
                        <select name="apoint_time" id="apoint_time" class="form-select">
                            <option value="">Select Time</option>
                            <option value="9-10" <?php if ($time == "9-10") { ?> Selected <?php } ?>>9-10 AM</option>
                            <option value="10-11" <?php if ($time == "10-11") { ?> Selected <?php } ?>>10-11 AM</option>
                            <option value="11-12" <?php if ($time == "11-12") { ?> Selected <?php } ?>>11-12 AM</option>
                            <option value="3-4" <?php if ($time == "3-4") { ?> Selected <?php } ?>>3-4 PM</option>
                            <option value="4-5" <?php if ($time == "4-5") { ?> Selected <?php } ?>>4-5 PM</option>
                            <option value="5-6" <?php if ($time == "5-6") { ?> Selected <?php } ?>>5-6 PM</option>
                            <option value="7-8" <?php if ($time == "7-8") { ?> Selected <?php } ?>>7-8 PM</option>
                            <option value="8-9" <?php if ($time == "8-9") { ?> Selected <?php } ?>>8-9 PM</option>
                        </select>
                        <label>Appointment Time</label>
                        <span id="tval" style="color:red;display:none;"> * Select Time </span>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type='text' class='form-control' placeholder='' autocomplete="off" id="reason" name="reason" value="<?php echo $reason ?>" />
                        <label>Reason Of Appointment</label>
                        <span id="rval" style="color:red;display:none;"> * Reason Required </span>
                    </div>

                    <div class="mb-4 buttons">
                        <input type="submit" value="Book Appointment" name="btn_bookappointment" class="btn btn-success " />
                        <input type="submit" value="Update" name="btn_update" class="btn btn-primary" />
                        <input type="reset" value="Reset" name="btn_reset" class="btn btn-danger " />
                    </div>
                </form>
            </div>

        </div>
    </div>
    <script>
        const today = new Date().toISOString().split('T')[0];
        document.getElementById("apoint_date").setAttribute("min", today);
        // console.log(today);
    </script>
</body>

</html>