<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>add_doctor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <link rel="stylesheet" href="../styles/add_doctorcss.css" type="text/css">
    <script>
        function validationDoctor() {
            var dname = document.getElementById("doctor_name").value;
            var pro = document.getElementById("profession").value;
            var add = document.getElementById("address").value;
            var mno = document.getElementById("mno").value;
            var email = document.getElementById("email").value;
            var uname = document.getElementById("uname").value;
            var pass = document.getElementById("password").value;
            var photo = document.getElementById("file_to_upload").value;


            if (!dname) {
                document.getElementById("dval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("dval").style.display = "none";
                }, 1200);

                return false;

            } else if (!pro) {
                document.getElementById("prval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("prval").style.display = "none";
                }, 1200);

                return false;

            } else if (!add) {
                document.getElementById("aval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("aval").style.display = "none";
                }, 1500);

                return false;
            } else if (!mno) {
                document.getElementById("mval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("mval").style.display = "none";
                }, 1500);

                return false;
            } else if (!email) {
                document.getElementById("eval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("eval").style.display = "none";
                }, 1500);

                return false;
            } else if (!uname) {
                document.getElementById("uval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("uval").style.display = "none";
                }, 1500);

                return false;
            } else if (!pass) {
                document.getElementById("pval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("pval").style.display = "none";
                }, 1500);

                return false;
            } else if (!photo) {
                document.getElementById("fval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("fval").style.display = "none";
                }, 1500);

                return false;
            } else {
                return true;
            }
        }
    </script>
</head>

<body>

    <?php
    include_once("databaseconnect.php");
    $conn = connection();

    if (!$conn) {
        echo "ERROR!!!";
    } else {
        session_start();
        if (!isset($_SESSION['admin'])) {
            header("Location:../../Login.php");
        }

        if (isset($_REQUEST["btn_adddoctor"])) {
            $dname = $_REQUEST["doctor_name"];
            $profession = $_REQUEST["profession"];
            $address = $_REQUEST["address"];
            $mno = $_REQUEST["mno"];
            $email = $_REQUEST["email"];
            $uname = $_REQUEST["uname"];
            $pwd = $_REQUEST["password"];

            $file_name = $_FILES["file_to_upload"]["name"];
            $tmp_name = $_FILES["file_to_upload"]["tmp_name"];
            $folder = './doctor_image/' . $file_name;

            $Q = "INSERT INTO doctors(doctor_name,profession,`address`,mno,email,uname,`password`,`image`) VALUES('$dname','$profession','$address','$mno','$email','$uname','$pwd','$file_name')";
            $result = mysqli_query($conn, $Q);

            if (move_uploaded_file($tmp_name, $folder)) {
    ?>
                <script>
                    alert("File Uploaded ....");
                </script>
            <?php
            } else {
            ?>
                <script>
                    alert("File not Uploaded ....");
                </script>
            <?php
            }


            if ($result) {
                header("Location:doctors.php");
            } else {
            ?>
                <script>
                    alert("Doctor Not Added ...");
                </script>
    <?php

            }
        }

        $dname = "";
        $pro = "";
        $add = "";
        $mno = "";
        $email = "";
        $uname = "";
        $password = "";

        if (isset($_REQUEST["doc_id"])) {
            $doctor_id = $_REQUEST["doc_id"];

            $q = "SELECT * FROM doctors WHERE doctor_id=$doctor_id";
            $result = mysqli_query($conn, $q);
            $data = $result->fetch_assoc();

            $dname = $data["doctor_name"];
            $pro = $data["profession"];
            $add = $data["address"];
            $mno = $data["mno"];
            $email = $data["email"];
            $uname = $data["uname"];
            $password = $data["password"];
            $img = $data["image"];
        }

        if (isset($_REQUEST["btn_update"])) {

            $updoc_id = $_REQUEST["doc_id"];
            $updoc_name = $_REQUEST["doctor_name"];
            $uppro = $_REQUEST["profession"];
            $upadd = $_REQUEST["address"];
            $upmno = $_REQUEST["mno"];
            $upemail = $_REQUEST["email"];
            $upuname = $_REQUEST["uname"];
            $uppwd = $_REQUEST["password"];

            // $upfile = $_FILES["file_to_upload"]["name"];
            // $uptemp = $_FILES["file_to_upload"]["tmp_name"];
            // $fld = './doctor_image/' . $upfile;
            // move_uploaded_file($uptemp, $fld);

            $q = "UPDATE doctors SET doctor_name='$updoc_name',profession='$uppro',`address`='$upadd',mno=$upmno,
            email='$upemail',uname='$upuname',`password`='$uppwd' WHERE doctor_id=$updoc_id";
            mysqli_query($conn, $q);
            header("location:doctors.php");
        }
    }
    ?>

    <div class="maincontainer">
        <div class="navbar">
            <?php include_once("navbar.php") ?>
        </div>

        <div class="content">

            <div class="doctorform" id="doctorform">

                <div class="heading2">
                    <h3 class="field_heading text-danger">Add New Doctors </h3>
                    <a href="doctors.php"><button class="btn btn-outline-primary">Back</button></a>
                </div>

                <!-- FORM FOR ADDING NEW DOCTORS -->


                <form method="post" class="form" enctype="multipart/form-data" onsubmit="return validationDoctor()">

                    <div class='form-floating mb-4'>
                        <input type='text' class='form-control' placeholder='' autocomplete="off" name="doctor_name" id="doctor_name" value="<?php echo $dname ?>" />
                        <label>Doctor Name </label>
                        <span id="dval" style="color:red;display:none;"> * Required </span>
                    </div>

                    <div class='form-floating mb-4'>
                        <select class="form-select" name="profession" id="profession">
                            <option>--Select Profession--</option>
                            <option value="Neuro Surgeons" <?php if ($pro == "Neuro Surgeons") { ?> selected <?php } ?>> Neuro Surgeons </option>
                            <option value="Plastic Surgeons" <?php if ($pro == "Plastic Surgeons") { ?> selected <?php } ?>> Plastic Surgeons </option>
                            <option value="Cardiothoracic Surgeons" <?php if ($pro == "Cardiothoracic Surgeons") { ?> selected <?php } ?>> Cardiothoracic Surgeons </option>
                            <option value="Arthopaedic Surgeons" <?php if ($pro == "Arthopaedic Surgeons") { ?> selected <?php } ?>> Arthopaedic Surgeons </option>
                            <option value="Urologists" <?php if ($pro == "Urologists") { ?> selected <?php } ?>> Urologists </option>
                            <option value="Radiologists" <?php if ($pro == "Radiologists") { ?> selected <?php } ?>> Radiologists </option>
                        </select>
                        <label> Profession </label>
                        <span id="prval" style="color:red;display:none;"> * Select Profession first </span>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type='text' class='form-control' placeholder='' autocomplete="off" name="address" id="address" value="<?php echo $add ?>" />
                        <label>Address</label>
                        <span id="aval" style="color:red;display:none;"> * Address Required </span>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type='tel' class='form-control' oninput="this.value = this.value.replace(/[^0-9]/, '');" maxlength="10" placeholder='' autocomplete="off" name="mno" id="mno" value="<?php echo $mno ?>" />
                        <label>Mobile No</label>
                        <span id="mval" style="color:red;display:none;"> * Required </span>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type='email' class='form-control' placeholder='' autocomplete="off" name="email" id="email" value="<?php echo $email ?>" />
                        <label>Email</label>
                        <span id="eval" style="color:red;display:none;"> * Email Mandatory </span>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type='text' class='form-control' placeholder='' autocomplete="off" name="uname" id="uname" value="<?php echo $uname ?>" />
                        <label>Username</label>
                        <span id="uval" style="color:red;display:none;"> * Username Required </span>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type="password" class="form-control" placeholder="Password" autocomplete="off" name="password" id="password" value="<?php echo $password ?>">
                        <label>Password</label>
                        <span id="pval" style="color:red;display:none;"> * Password Required </span>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type='file' accept="image/png, image/jpeg" class='form-control' placeholder='' autocomplete="off" id="file_to_upload" name="file_to_upload" />
                        <label>Image</label>
                        <span id="fval" style="color:red;display:none;"> * Upload Photo first </span>
                    </div>

                    <?php if (isset($img)) { ?>
                        <div class="my-3">
                            <img src="./doctor_image/<?php echo $img ?>" alt="" height="50">
                            <?php echo $img; ?>
                        </div>
                    <?php } ?>

                    <div class="mb-4 buttons">
                        <input type="submit" value="Add New Doctor" name="btn_adddoctor" class="btn btn-success " />
                        <input type="submit" value="Update" name="btn_update" class="btn btn-primary" />
                        <input type="reset" value="Reset" name="btn_reset" class="btn btn-danger " />
                    </div>
                </form>
            </div>
        </div>
    </div>

</body>

</html>