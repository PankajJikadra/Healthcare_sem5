<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>add_Patient</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <link rel="stylesheet" href="../styles/add_patientcss.css" type="text/css">
    <script>
        function validationPatient() {
            var pname = document.getElementById("patient_name").value;
            var age = document.getElementById("age").value;
            var mno = document.getElementById("mno").value;
            var email = document.getElementById("email").value;
            var uname = document.getElementById("uname").value;
            var pass = document.getElementById("password").value;

            if (!pname) {
                document.getElementById("pval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("pval").style.display = "none";
                }, 1200);

                return false;

            } else if (!age) {
                document.getElementById("aval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("aval").style.display = "none";
                }, 1500);

                return false;
            } else if (!mno) {
                document.getElementById("mval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("mval").style.display = "none";
                }, 1500);

                return false;
            } else if (!email) {
                document.getElementById("eval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("eval").style.display = "none";
                }, 1500);

                return false;
            } else if (!uname) {
                document.getElementById("uval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("uval").style.display = "none";
                }, 1500);

                return false;
            } else if (!pass) {
                document.getElementById("psval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("psval").style.display = "none";
                }, 1500);

                return false;
            }
            else {
                return true;
            }
        }
    </script>
</head>

<body>

    <?php
    include_once("databaseconnect.php");
    $conn = connection();

    if (!$conn) {
        echo "ERROR!!!";
    } else {
        session_start();
        if (!isset($_SESSION['admin'])) {
            header("Location:../../Login.php");
        }

        // if ($result) {
        //     header("Location:patient.php");
        // } else {
    ?>
        <script>
            //alert("Patient Not Added ...");
        </script>
    <?php
    }
    // }

    if (isset($_REQUEST["btn_addpatient"])) {
        $pname = $_REQUEST["patient_name"];
        $gender = $_REQUEST["gender"];
        $age = $_REQUEST["age"];
        $mno = $_REQUEST["mno"];
        $email = $_REQUEST["email"];
        $uname = $_REQUEST["uname"];
        $password = $_REQUEST["password"];

        $q = "INSERT INTO patients VALUES ('','$pname','$gender',$age,$mno,'$email','$uname','$password')";
        $result = mysqli_query($conn, $q);
    }


    $up_pname = "";
    $up_gender = "";
    $up_age = "";
    $up_mno = "";
    $up_email = "";
    $up_uname = "";
    $up_password = "";

    if (isset($_REQUEST["pid"])) {
        $pid = $_REQUEST["pid"];

        $result = mysqli_query($conn, "SELECT * FROM patients WHERE patient_id=$pid");
        $patient_data = mysqli_fetch_array($result);

        $up_pname = $patient_data["patient_name"];
        $up_gender = $patient_data["gender"];
        $up_age = $patient_data["age"];
        $up_mno = $patient_data["mno"];
        $up_email = $patient_data["email"];
        $up_uname = $patient_data["uname"];
        $up_password = $patient_data["password"];
    }

    if (isset($_REQUEST["btn_update"])) {
        $pid = $_REQUEST["pid"];
        $pname = $_REQUEST["patient_name"];
        $gender = $_REQUEST["gender"];
        $age = $_REQUEST["age"];
        $mno = $_REQUEST["mno"];
        $email = $_REQUEST["email"];
        $uname = $_REQUEST["uname"];
        $password = $_REQUEST["password"];

        $q = "UPDATE patients SET patient_name='$pname',gender='$gender',age=$age,mno=$mno,email='$email',
        uname='$uname',`password`='$password' WHERE patient_id=$pid";
        mysqli_query($conn, $q);
    }
    ?>

    <div class="maincontainer">
        <div class="navbar">
            <?php include_once("navbar.php") ?>
        </div>

        <div class="content">

            <div class="patientform" id="patientform">

                <div class="heading2">
                    <h3 class="field_heading text-danger">Add New Patients </h3>
                    <a href="patient.php"><button class="btn btn-outline-primary">Back</button></a>
                </div>

                <!-- FORM FOR ADDING NEW PATIENTS -->


                <form method="post" class="form" enctype="multipart/form-data" onsubmit="return validationPatient()">

                    <div class='form-floating mb-4'>
                        <input type='text' class='form-control' placeholder='' autocomplete="off" name="patient_name" id="patient_name" value="<?php echo $up_pname ?>" />
                        <label>Patient Name </label>
                        <span id="pval" style="color:red;display:none;"> * Patient Name Required </span>
                    </div>

                    <div class='form-check mb-4'>
                        <input type='radio' class="form-check-input" id="P_Male" placeholder='' name="gender" value="Male" <?php if ($up_gender == "Male") { ?> checked <?php } ?> checked/>
                        <label class="form-check-label">Male</label>
                    </div>

                    <div class='form-check mb-4'>
                        <input type='radio' class="form-check-input" id="P_Male" placeholder='' name="gender" value="Female" <?php if ($up_gender == "Female") { ?> checked <?php } ?> />
                        <label class="form-check-label">Female</label>
                    </div>

                    <div class='form-floating mb-4 my-4'>
                        <input type='text' class='form-control' placeholder='' maxlength="3" oninput="this.value = this.value.replace(/\D/, '');" autocomplete="off" name="age" id="age" value="<?php echo $up_age ?>" />
                        <label>Age</label>
                        <span id="aval" style="color:red;display:none;"> * Required </span>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type='tel' class='form-control' placeholder='' oninput="this.value = this.value.replace(/[^0-9]/, '');" maxlength="10" autocomplete="off" name="mno" id="mno" value="<?php echo $up_mno ?>" />
                        <label>Mobile No</label>
                        <span id="mval" style="color:red;display:none;"> * MobileNo Required </span>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type='email' class='form-control' placeholder='' autocomplete="off" name="email" id="email" value="<?php echo $up_email ?>" />
                        <label>Email</label>
                        <span id="eval" style="color:red;display:none;"> * Email mandatory </span>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type='text' class='form-control' placeholder='' autocomplete="off" name="uname" id="uname" value="<?php echo $up_uname ?>" />
                        <label>Username</label>
                        <span id="uval" style="color:red;display:none;"> * Invalid Username </span>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type="password" class="form-control" placeholder="Password" autocomplete="off" name="password" id="password" value="<?php echo $up_password ?>" />
                        <label>Password</label>
                        <span id="psval" style="color:red;display:none;"> * Password Invalid </span>
                    </div>

                    <div class="mb-4 buttons">
                        <input type="submit" value="Add New Patient" name="btn_addpatient" class="btn btn-success " />
                        <input type="submit" value="Update" name="btn_update" class="btn btn-primary" />
                        <input type="reset" value="Reset" name="btn_reset" class="btn btn-danger " />
                    </div>
                </form>
            </div>
        </div>
    </div>

</body>

</html>