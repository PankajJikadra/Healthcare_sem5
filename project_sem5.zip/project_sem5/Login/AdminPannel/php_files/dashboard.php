<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <link rel="stylesheet" href="../styles/dashboardcss.css" type="text/css">
    <link rel="stylesheet" href="../styles/navbarcss.css" type="text/css">
    <link rel="website icon" href="../images/logo.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

</head>

<body>
    <?php
    include_once("databaseconnect.php");

    $conn = connection();

    if (!$conn) {
        echo "ERROR!!!";
    } else {
        session_start();
        if (!isset($_SESSION['admin'])) {
            header("Location:../../Login.php");
        } else {
            $Q1 = "SELECT * FROM doctors";
            $result1 = mysqli_query($conn, $Q1);
            $doctors = mysqli_num_rows($result1);

            $Q2 = "SELECT * FROM appointment";
            $result2 = mysqli_query($conn, $Q2);
            $patients = mysqli_num_rows($result2);

            $Q3 = "SELECT * FROM appointment where `date`=CURDATE()";
            $result3 = mysqli_query($conn, $Q3);
            $todaypatients = mysqli_num_rows($result3);
        }
    }
    ?>
    <div class="maincontainer">
        <div class="navbar">
            <?php include_once("navbar.php") ?>
        </div>

        <div class="content">
            <div class="heading">
                <h1>Dashboard</h1>
                <img src="../images/admin.svg" alt="ADMINLOGO" height="50">
            </div>

            <div class="dashboard_details">
                <div class="card" id="card1">
                    <h4>Total Doctors</h4>
                    <h3> <?php echo $doctors ?></h3>
                    <a href="./doctors.php">View Details</a>
                </div>

                <div class="card" id="card2">
                    <h4>Todays Appointments</h4>
                    <h3> <?php echo $todaypatients ?></h3>
                    <a href="./todays_appointment.php">View Details</a>
                </div>

                <div class="card" id="card3">
                    <h4>Total Appointments</h4>
                    <h3> <?php echo $patients ?></h3>
                    <a href="./appointment.php">View Details</a>
                </div>
            </div>

            <div class="btn_addappiontment my-4 mb-5">
                <a href="../php_files/add_appointment.php"><button class="btn btn-outline-primary">Add New Appointment</button></a>
            </div>

            <div class="doctor_patient">
                <div class="todaypatients">

                    <h1 class="text-danger mb-3">Todays Appointments</h1>
                    <table class="table table-striped">
                        <thead class="table-dark">
                            <tr>
                                <th scope="col"></th>
                                <th scope="col">Patient Name</th>
                                <th scope="col">Doctor Name</th>
                                <th scope="col">appointment Date</th>
                                <th scope="col">Status</th>
                        </thead>

                        <tbody>
                            <?php
                            while ($today = $result3->fetch_assoc()) {
                            ?>
                                <tr>
                                    <td><img src="../images/person-circle.svg" alt="Avtar" class="avtar"></td>
                                    <?php
                                    $dbpatient_id = $today["patient_id"];
                                    $res = mysqli_query($conn, "SELECT patient_name FROM patients WHERE patient_id=$dbpatient_id");
                                    $patientName = mysqli_fetch_array($res);
                                    ?>
                                    <td><?php echo $patientName['patient_name'] ?></td>
                                    <?php
                                    $dbdoctor_id = $today["doctor_id"];
                                    $res = mysqli_query($conn, "SELECT doctor_name FROM doctors WHERE doctor_id=$dbdoctor_id");
                                    $doctorName = mysqli_fetch_array($res);
                                    ?>
                                    <td><?php echo $doctorName['doctor_name'] ?></td>
                                    <td><?php echo $today['date'] ?></td>
                                    <td><?php echo $today['status'] ?></td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

                <div class="doctors">
                    <h1 class="text-danger mb-3">All Doctors</h1>

                    <table class="table table-striped">
                        <tbody>
                            <?php
                            while ($doctor = $result1->fetch_assoc()) {
                            ?>
                                <tr>
                                    <td><img src="../images/user-md-solid.svg" alt="Avtar" class="avtar"></td>
                                    <td><?php echo $doctor['doctor_name'] ?></td>
                                    <td><?php echo $doctor['profession'] ?></td>

                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</body>

</html>