<?php 
    function connection()
    {
        $conn=mysqli_connect("localhost","root","","healthcare");
        return $conn;
    }
?>