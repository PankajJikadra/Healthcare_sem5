<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctors</title>

    <link rel="stylesheet" href="../styles/doctorscss.css" type="text/css">
    <link rel="website icon" href="../images/logo.png"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>

    <?php
    include_once("databaseconnect.php");

    $conn = connection();

    if (!$conn) {
        echo "ERROR!!!";
    } else {
        session_start();
        if (!isset($_SESSION['admin'])) {
            header("Location:../../Login.php");
        }

        $Q = "SELECT * FROM doctors";
        $record = mysqli_query($conn, $Q);
    }
    ?>

    <div class="maincontainer">
        <div class="navbar">
            <?php include_once("navbar.php") ?>
        </div>

        <div class="content">
            <div class="heading">
                <h1>Doctors</h1>
                <img src="../images/user-md-solid.svg" alt="LOGO" class="avtar">
            </div>

            <div class="doctordetails">

                <div class="heading2">
                    <h3 class="field_heading text-danger">Doctors Details</h3>
                    <a href="add_doctor.php"><button class="btn btn-outline-primary">Add New Doctors</button></a>
                </div>


                <table class="table table-striped">
                    <thead class="table-dark ">
                        <tr>
                            <th scope="col">Doctor_ID</th>
                            <th scope="col">Doctor_Name</th>
                            <th scope="col">Profession</th>
                            <th scope="col">Address</th>
                            <th scope="col">MoblieNo</th>
                            <th scope="col">Email</th>
                            <th scope="col">Username</th>
                            <th scope="col">Photo</th>
                            <th scope="col">Status</th>
                            <th scope="col">Update</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        while ($data = $record->fetch_assoc()) {
                        ?>
                            <tr>
                                <td><?php echo $data["doctor_id"] ?></td>
                                <td><?php echo $data["doctor_name"] ?></td>
                                <td><?php echo $data["profession"] ?></td>
                                <td><?php echo $data["address"] ?></td>
                                <td><?php echo $data["mno"] ?></td>
                                <td><?php echo $data["email"] ?></td>
                                <td><?php echo $data["uname"] ?></td>
                                <td><img src="../doctor_image/<?php echo $data["image"] ?>" alt="img" class="img"></td>
                                <td>
                                    <?php
                                    if ($data["status"] == "Active") {
                                        echo '<a href="status1.php?did=' . $data["doctor_id"] . '&status=Inactive"> <button class="btn btn-success"> Active </button></a>';
                                    } else {
                                        echo '<a href="status1.php?did=' . $data["doctor_id"] . '&status=Active"> <button class="btn btn-danger"> Inactive </button></a>';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <a href="add_doctor.php?doc_id=<?php echo $data["doctor_id"] ?>">
                                        <button class="btn btn-primary"> Edit </button>
                                    </a>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>


            </div>



        </div>

    </div>
</body>

</html>