<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Feedback </title>
    <link rel="stylesheet" href="../styles/feedbackcss.css">
    <link rel="website icon" href="../images/logo.png"/>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <?php
    include_once("databaseconnect.php");

    $conn = connection();

    if (!$conn) {
        echo "ERROR!!!";
    } else {
        session_start();
        if (!isset($_SESSION['admin'])) {
            header("Location:../../Login.php");
        }

        $result = mysqli_query($conn, "SELECT * FROM feedback");
    }
    ?>

    <div class="maincontainer">
        <div class="navbar">
            <?php include_once("navbar.php") ?>
        </div>

        <div class="content">
            <div class="heading">
                <h1>FeedBack</h1>
                <img src="../images/feedback.svg" alt="LOGO" class="avtar">
            </div>

            <div class="feedbackdetails">

                <div class="heading2">
                    <h3 class="field_heading text-danger">Feedback Details</h3>
                </div>

                <table class="table table-striped table-light ">
                    <thead class="table-dark ">
                        <tr>
                            <th scope="col">FeedBack_ID</th>
                            <th scope="col">Full Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Feedback</th>
                            <th scope="col">Approved</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        while ($feedback_record = mysqli_fetch_array($result)) {
                        ?>
                            <tr>
                                <td><?php echo $feedback_record["feedback_id"] ?></td>
                                <td><?php echo $feedback_record["fname"] ?></td>
                                <td><?php echo $feedback_record["email"] ?></td>
                                <td><?php echo $feedback_record["feedback"] ?></td>
                                <td>
                                    <?php
                                    if ($feedback_record["status"] == "Show") {
                                        echo '<a href="show.php?fid=' . $feedback_record["feedback_id"] . '&status=Unshow"> <button class="btn btn-primary"> show </button></a>';
                                    } else {
                                        echo '<a href="show.php?fid=' . $feedback_record["feedback_id"] . '&status=Show"> <button class="btn btn-danger"> Unshow </button></a>';
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>

</html>