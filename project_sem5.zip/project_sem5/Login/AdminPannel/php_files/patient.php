<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient</title>
    <link rel="stylesheet" href="../styles/patientcss.css">
    <link rel="website icon" href="../images/logo.png"/>
</head>

<body>
    <?php
    include_once("databaseconnect.php");

    $conn = connection();

    if (!$conn) {
        echo "ERROR!!!";
    } else {
        session_start();
        if (!isset($_SESSION['admin'])) {
            header("Location:../../Login.php");
        }

        $fetch_patients = "SELECT * FROM patients";
        $record = mysqli_query($conn, $fetch_patients);
    }
    ?>

    <div class="maincontainer">
        <div class="navbar">
            <?php include_once("navbar.php") ?>
        </div>

        <div class="content">
            <div class="heading">
                <h1>Patients</h1>
                <img src="../images/patient-profile-people-svgrepo-com.svg" alt="LOGO" class="avtar">
            </div>

            <div class="patientdetails">

                <div class="heading2">
                    <h3 class="field_heading text-danger">Patients Details</h3>
                    <a href="add_patient.php"><button class="btn btn-outline-primary">Add New Patient</button></a>
                </div>

                <table class="table table-striped table-light ">
                    <thead class="table-dark ">
                        <tr>
                            <th scope="col">Patient_ID</th>
                            <th scope="col">Patient_Name</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Age</th>
                            <th scope="col">Moblie No</th>
                            <th scope="col">Email</th>
                            <th scope="col">Username</th>
                            <th scope="col">Update</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        while ($data = $record->fetch_assoc()) {
                        ?>
                            <tr>
                                <td><?php echo $data["patient_id"] ?></td>
                                <td><?php echo $data["patient_name"] ?></td>
                                <td><?php echo $data["gender"] ?></td>
                                <td><?php echo $data["age"] ?></td>
                                <td><?php echo $data["mno"] ?></td>
                                <td><?php echo $data["email"] ?></td>
                                <td><?php echo $data["uname"] ?></td>
                                <td>
                                    <a href="add_patient.php?pid=<?php echo $data["patient_id"] ?>">
                                        <button class="btn btn-primary"> Edit </button>
                                    </a>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

</body>

</html>