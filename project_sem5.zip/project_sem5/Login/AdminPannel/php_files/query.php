<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Query</title>
    <link rel="stylesheet" href="../styles/querycss.css">
    <link rel="website icon" href="../images/logo.png">
    <!-- <script>
        function openmail(email) {
            // window.open(`mailto:${email}`);
            console.log(email);
        }
    </script> -->
</head>

<body>
    <?php
    session_start();

    if (!isset($_SESSION['admin'])) 
    {
        header("Location:../../Login.php");
    }
    $conn = mysqli_connect("localhost", "root", "", "healthcare");
    $result = mysqli_query($conn, "SELECT * FROM query");
    ?>

    <div class="maincontainer">
        <div class="navbar">
            <?php include_once("navbar.php") ?>
        </div>

        <div class="content">
            <div class="heading">
                <h1>Query</h1>
                <img src="../images/ask-svgrepo-com.svg" alt="LOGO" class="avtar">
            </div>

            <div class="querydetails">

                <div class="heading2">
                    <h3 class="field_heading text-danger">Query Details</h3>
                </div>

                <table class="table table-striped table-light ">
                    <thead class="table-dark ">
                        <tr>
                            <th scope="col">Query_id</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Qurey</th>
                            <th scope="col">Response</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        while ($query_data = mysqli_fetch_assoc($result)) {
                        ?>
                            <tr>
                                <td> <?php echo $query_data["query_id"] ?> </td>
                                <td> <?php echo $query_data["name"] ?> </td>
                                <td> <?php echo $query_data["email"] ?> </td>
                                <td> <?php echo $query_data["query"] ?> </td>
                                <td>
                                    <?php
                                    if ($query_data["response"] == "Response") {
                                        echo '<a href="status2.php?qid=' . $query_data["query_id"] . '&response=Sent"> 
                                        <button class="btn btn-primary" 
                                        onclick="location.href=`mailto:' . $query_data["email"] . '`"> Response </button></a>';
                                    } else {
                                        echo '<a href="status2.php?qid=' . $query_data["query_id"] . '&response=Response"> 
                                        <button class="btn btn-success"> Sent </button> </a>';
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>

</html>