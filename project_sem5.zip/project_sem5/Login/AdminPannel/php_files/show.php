<?php
include_once("./databaseconnect.php");

function FeedbackShow()
{
    $conn = connection();
    $fid = $_REQUEST["fid"];
    $status = $_REQUEST["status"];
    $query = "update feedback set status='$status' where feedback_id=$fid";
    mysqli_query($conn, $query);
    header("Location:feedback.php"); 
}

FeedbackShow();
?>