<?php
    include_once("./databaseconnect.php");
    session_start(); 
      
    function DoctorStatus() {  
        $conn = connection();
        $did = $_REQUEST["did"];
        $status = $_REQUEST["status"];
        $query = "update doctors set status='$status' where doctor_id=$did";
        mysqli_query($conn, $query);
        header("Location:doctors.php");  
    }

    DoctorStatus();
?>