<?php
    include_once("./databaseconnect.php");

    function queryStatus() {     
        $conn = connection();
        $qid = $_REQUEST["qid"];
        $response = $_REQUEST["response"];
        $query = "update query set response='$response' where query_id=$qid";
        mysqli_query($conn, $query);
        header("Location:query.php");  
    }

    queryStatus();

?>