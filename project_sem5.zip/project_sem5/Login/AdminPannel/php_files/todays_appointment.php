<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    
    <link rel="stylesheet" href="../styles/todays_appointmentcss.css" type="text/css">
</head>
<body>
    <?php 
        include_once("databaseconnect.php");

        $conn=connection();
 
        if(!$conn)
        {
            echo "ERROR!!!";
        }
        else
        { 
            session_start();
            if(!isset($_SESSION['admin']))
            {
                header("Location:../../Login.php");
            }
            $fetch_patients="SELECT * FROM appointment WHERE `date`=CURDATE()";
            $record=mysqli_query($conn,$fetch_patients);
        }
    ?>

    <div class="maincontainer">
        <div class="navbar">
            <?php include_once("navbar.php") ?>
        </div>

        <div class="content">
            <div class="heading">
                <h1>Appointments</h1>
                <img src="../images/calendar-check-regular.svg" alt="LOGO" class="avtar">
            </div>

            <div class="patientdetails">
                
                <div class="heading2">
                    <h3 class="field_heading text-danger">Todays Appointment Details</h3>
                    <a href="dashboard.php"><button class="btn btn-outline-primary">Back To Dashboard</button></a>
                </div>

                <table class="table table-striped table-light ">
                    <thead class="table-dark ">
                        <tr>
                            <th scope="col">Appoint_id</th>
                            <th scope="col">Patient_ID</th>
                            <th scope="col">Doctor ID</th>
                            <th scope="col">Appointment Date</th>
                            <th scope="col">Appointment Time</th>
                            <th scope="col">Reason</th>
                            <th scope="col">Status</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                            while($data=$record->fetch_assoc())
                            {
                        ?>
                            <tr>
                                <td><?php echo $data["appoint_id"] ?></td>
                                <td><?php echo $data["patient_id"] ?></td>
                                <td><?php echo $data["doctor_id"] ?></td>
                                <td><?php echo $data["date"] ?></td>
                                <td><?php echo $data["time"] ?></td>
                                <td><?php echo $data["reason"] ?></td>
                                <td><?php echo $data["status"] ?></td>
                            </tr>
                        <?php
                           }
                        ?>
                    </tbody>
                </table>
            </div> 
        </div>
    </div>
</body>
</html>