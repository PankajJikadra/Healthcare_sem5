<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <link rel="stylesheet" href="../styles/appointmentcss.css" type="text/css">
</head>

<body>
    <?php
    include_once("databaseconnect.php");

    $conn = connection();

    if (!$conn) 
    {
        echo "ERROR!!!";
    }
    else 
    {
        session_start();
        if (!isset($_SESSION['doctor'])) 
        {
            header("Location:../../Login.php");
        }
        $doctor_id=$_SESSION['doctor'];
        $fetch_appointmnet = "SELECT * FROM appointment WHERE doctor_id=$doctor_id";
        $record = mysqli_query($conn, $fetch_appointmnet);
    }
    ?>

    <div class="maincontainer">
        <div class="navbar">
            <?php include_once("navbar.php") ?>
        </div>

        <div class="content">
            <div class="heading">
                <h1>Appointments</h1>
                <img src="../images/calendar-check-regular.svg" alt="LOGO" class="avtar">
            </div>

            <div class="patientdetails">

                <div class="heading2">
                    <h3 class="field_heading text-danger">Appointment Details</h3>
                    <a href="add_appointment.php"><button class="btn btn-outline-primary">Add New Appointment</button></a>
                </div>

                <table class="table table-striped table-light ">
                    <thead class="table-dark ">
                        <tr>
                            <th scope="col">Appintment_Id</th>
                            <th scope="col">Patient_Name</th>
                            <th scope="col">Doctor_Name</th>
                            <th scope="col">Date</th>
                            <th scope="col">Time</th>
                            <th scope="col">Reason</th>
                            <th scope="col">Status</th>
                            <th scope="col">Update</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        while ($data = $record->fetch_assoc()) {
                        ?>
                            <tr>
                                <td><?php echo $data["appoint_id"] ?></td>
                                <?php
                                $pid = $data['patient_id'];
                                $patients = $conn->query("SELECT * FROM patients WHERE patient_id=$pid");
                                $patient_record = $patients->fetch_assoc();
                                ?>
                                <td><?php echo $patient_record["patient_name"] ?></td>
                                <?php
                                $did = $data['doctor_id'];
                                $doctors = $conn->query("SELECT * FROM doctors where doctor_id=$did");
                                $doctor_record = $doctors->fetch_assoc();
                                ?>
                                <td><?php echo $doctor_record["doctor_name"] ?></td>
                                <td><?php echo $data["date"] ?></td>
                                <td><?php echo $data["time"] ?></td>
                                <td><?php echo $data["reason"] ?></td>

                                <td>
                                    <?php
                                    if ($data["status"] == "Approved") {
                                        echo '<a href="status.php?aid=' . $data["appoint_id"] . '&status=Disapproved"> <button class="btn btn-success"> Approved </button></a>';
                                    } else {
                                        echo '<a href="status.php?aid=' . $data["appoint_id"] . '&status=Approved"> <button class="btn btn-danger"> Dispproved </button></a>';
                                    }
                                    ?>
                                </td>

                                <td>
                                    <a href="add_appointment.php?update_id=<?php echo $data["appoint_id"] ?>">
                                        <button class="btn btn-primary"> Edit </button>
                                    </a>
                                </td>

                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>

</html>