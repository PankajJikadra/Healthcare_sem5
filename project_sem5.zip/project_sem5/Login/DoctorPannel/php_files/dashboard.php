<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <link rel="stylesheet" href="../styles/dashboardcss.css" type="text/css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

</head>

<body>
    <?php
    include_once("databaseconnect.php");

    $conn = connection();

    if(!$conn) {
        echo "ERROR!!!";
    }
    else 
    {
        session_start();
        
        if (!isset($_SESSION['doctor'])) 
        {
            header("Location:../../Login.php");
            
        }
        else 
        {
            $doctor_id=$_SESSION['doctor'];
            $doctor=mysqli_query($conn,"SELECT * FROM doctors WHERE doctor_id=$doctor_id");
            $doctor_details=mysqli_fetch_assoc($doctor);

            $Q2 = "SELECT * FROM appointment WHERE doctor_id=$doctor_id";
            $result2 = mysqli_query($conn, $Q2);
            $total_appoint = mysqli_num_rows($result2);

            $Q3 = "SELECT * FROM appointment WHERE doctor_id=$doctor_id AND `date`=CURDATE()";
            $result3 = mysqli_query($conn, $Q3);
            $todaypatients = mysqli_num_rows($result3);
        }
    }
    ?>
    <div class="maincontainer">
        <div class="navbar">
            <?php include_once("navbar.php") ?>
        </div>

        <div class="content">
            <div class="heading">
                <h1>Welcome <?php echo $doctor_details['doctor_name'] ?></h1>
                <img src="../../AdminPannel/doctor_image/<?php echo $doctor_details["image"] ?>" alt="ADMINLOGO" id="doctor_image_icon">
            </div>

            <div class="dashboard_details">
                <div class="card" id="card1">
                    <h4>Todays Appointments</h4>
                    <h3> <?php  echo $todaypatients ?></h3>
                    <a href="./todays_appointment.php">View Details</a>
                </div>

                <div class="card" id="card2">
                    <h4>Total Appointments</h4>
                    <h3> <?php echo $total_appoint; ?></h3>
                    <a href="appointment.php">View Details</a>
                </div>

            </div>

            <div class="btn_addappiontment my-4 mb-5">
                <a href="add_appointment.php"><button class="btn btn-outline-primary">Add New Appointment</button></a>
            </div>

            <div class="doctor_patient">
                <div class="todaypatients">

                    <h1 class="text-danger mb-3">Todays Appointments</h1>
                    <table class="table table-striped">
                        <thead class="table-dark">
                            <tr>
                                <th scope="col"></th>
                                <th scope="col">Patient</th>
                                <th scope="col">Doctor</th>
                                <th scope="col">Appointment Date</th>
                                <th scope="col">Appointment Time</th>
                                <th scope="col">Status</th>
                        </thead>

                        <tbody>
                            <?php
                            while ($today = $result3->fetch_assoc()) 
                            {
                                $p_id=$today["patient_id"];
                                $d_id=$today["doctor_id"];

                                $q1="SELECT * FROM patients WHERE patient_id=$p_id";
                                $q2="SELECT * FROM doctors WHERE doctor_id=$d_id";

                                $r1=mysqli_query($conn,$q1);
                                $r2=mysqli_query($conn,$q2);

                                $patient=mysqli_fetch_assoc($r1);
                                $doctor=mysqli_fetch_assoc($r2);

                            ?>
                                <tr>
                                    <td><img src="../images/person-circle.svg" alt="Avtar" class="avtar"></td>
                                    <td><?php echo $patient['patient_name'] ?></td>
                                    <td><?php echo $doctor['doctor_name'] ?></td>
                                    <td><?php echo $today['date'] ?></td>
                                    <td><?php echo $today['time'] ?></td>
                                    <td><?php echo $today['status'] ?></td>
                                </tr>
                            <?php
                              }
                            ?>
                        </tbody>
                    </table>
                </div>

            </div>

        </div>
    </div>
</body>

</html>