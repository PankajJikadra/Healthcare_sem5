<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Health Care</title>
    <link rel="stylesheet" href="../styles/navbarcss.css" type="text/css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

</head>

<body>
    <?php

    if(isset(($_REQUEST['btn_logout']))) {
        session_start();
        session_unset();
        session_destroy();
        header("Location:../../Login.php");
    }
    ?>

    <div class="sidenavbar">
        <div class="logo">
            <img src="../images/logo.png" alt="logo" id="logo">
        </div>
        <h2>Healthcare</h2>
        <div class="listitems">
            <ul>
                <li class="list"><img src="../images/icons8-dashboard-50.png" alt="" class="icon"> <a href="dashboard.php">Dashboard</a></li>
                <li class="list"><img src="../images/calendar-days-solid.svg" alt="" class="icon"><a href="appointment.php">Appointments</a></li>
                <li class="list"><img src="../images/profile.svg" alt="" class="icon"><a href="profile.php">Edit Profile</a></li>
            </ul>
        </div>
        <form action="navbar.php" method="post">
            <button type="submit" class="btn btn-outline-danger btn_logout" name="btn_logout"><img src="../images/right-from-bracket-solid.svg" alt="" class="icon"> Logout</button>
        </form>
    </div>




</body>

</html>