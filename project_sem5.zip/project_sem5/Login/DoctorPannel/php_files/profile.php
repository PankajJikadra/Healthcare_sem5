<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <link rel="stylesheet" href="../styles/profilecss.css" type="text/css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

</head>

<body>
    <?php
    include_once("databaseconnect.php");

    $conn = connection();

    if(!$conn) {
        echo "ERROR!!!";
    }
    else 
    {
        session_start();
        
        if (!isset($_SESSION['doctor'])) 
        {
            header("Location:../../Login.php");
        }
        else 
        {
            $doctor_id=$_SESSION['doctor'];
            $doctor=mysqli_query($conn,"SELECT * FROM doctors WHERE doctor_id=$doctor_id");
            $doctor_details=mysqli_fetch_assoc($doctor);
            
            $id=$doctor_details["doctor_id"];
            $name=$doctor_details["doctor_name"];
            $pro=$doctor_details["profession"];
            $address=$doctor_details["address"];
            $mno=$doctor_details["mno"];
            $email=$doctor_details["email"];
            $uname=$doctor_details["uname"];
            $password=$doctor_details["password"];
            $image=$doctor_details["image"];

            if (isset($_REQUEST["btn_update"])) {

                $updoc_name = $_REQUEST["doctor_name"];
                $uppro = $_REQUEST["profession"];
                $upadd = $_REQUEST["address"];
                $upmno = $_REQUEST["mno"];
                $upemail = $_REQUEST["email"];
                $upuname= $_REQUEST["uname"];
                $uppwd = $_REQUEST["password"];
    
                $q = "UPDATE doctors SET doctor_name='$updoc_name',profession='$uppro',`address`='$upadd',mno=$upmno,
                email='$upemail',uname='$upuname',`password`='$uppwd' WHERE doctor_id=$id";
                mysqli_query($conn, $q);
            }
        }
    }
    ?>
    <div class="maincontainer">
        <div class="navbar">
            <?php include_once("navbar.php") ?>
        </div>

        <div class="content">
            <div class="heading">
                <h1>Manage Profile</h1>
                <img src="../../AdminPannel/doctor_image/<?php echo $image?>" alt="ADMINLOGO" id="doctor_image_icon">
            </div>

            <div class="details">
                <div class="heading2">
                    <h3 class="field_heading text-danger">Appointment Details</h3>
                </div>  

                <form method="post" class="form" enctype="multipart/form-data">

                    <div class='form-floating mb-4'>
                        <input type='text' class='form-control' placeholder='' autocomplete="off" name="doctor_name" value="<?php echo $name ?>" />
                        <label>Doctor Name </label>
                    </div>

                    <div class='form-floating mb-4'>
                        <select class="form-select" name="profession">
                            <option>--select profession--</option>
                            <option value="Neuro Surgeons" <?php if ($pro == "Neuro Surgeons") { ?> selected <?php } ?>> Neuro Surgeons </option>
                            <option value="Plastic Surgeons" <?php if ($pro == "Plastic Surgeons") { ?> selected <?php } ?>> Plastic Surgeons </option>
                            <option value="Cardiothoracic Surgeons" <?php if ($pro == "Cardiothoracic Surgeons") { ?> selected <?php } ?>> Cardiothoracic Surgeons </option>
                            <option value="Arthopaedic Surgeons" <?php if ($pro == "Arthopaedic Surgeons") { ?> selected <?php } ?>> Arthopaedic Surgeons </option>
                            <option value="Urologists" <?php if ($pro == "Urologists") { ?> selected <?php } ?>> Urologists </option>
                            <option value="Radiologists" <?php if ($pro == "Radiologists") { ?> selected <?php } ?>> Radiologists </option>
                        </select>
                        <label> Profession </label>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type='text' class='form-control' placeholder='' autocomplete="off" name="address" value="<?php echo $address ?>" />
                        <label>Address</label>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type='tel' class='form-control' placeholder='' autocomplete="off" name="mno" value="<?php echo $mno ?>" />
                        <label>Mobile No</label>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type='email' class='form-control' placeholder='' autocomplete="off" name="email" value="<?php echo $email ?>" />
                        <label>Email</label>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type='text' class='form-control' placeholder='' autocomplete="off" name="uname" value="<?php echo $uname ?>" />
                        <label>Username</label>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type="text" class="form-control" placeholder="Password" autocomplete="off" name="password" value="<?php echo $password ?>">
                        <label>Password</label>
                    </div>

                    <div class="mb-4 buttons">
                        <input type="submit" value="Update" name="btn_update" class="btn btn-primary" />
                        <input type="reset" value="Reset" name="btn_reset" class="btn btn-danger " />
                    </div>
                </form>
            </div>

        </div>
    </div>
</body>

</html>