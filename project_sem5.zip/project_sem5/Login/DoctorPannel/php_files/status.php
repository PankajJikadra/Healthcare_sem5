<?php
    include_once("./databaseconnect.php");

    $conn = connection();
    $aid = $_REQUEST["aid"];
    $status = $_REQUEST["status"];
    $query = "update appointment set status='$status' where appoint_id=$aid";
    mysqli_query($conn, $query);
    header("Location:./appointment.php");
      
?>