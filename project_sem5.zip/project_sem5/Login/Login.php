<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="Logincss.css" type="text/css" />
    <link rel="website icon"href="../images/logo.png"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <?php
    $conn = mysqli_connect("localhost", "root", "", "healthcare");
    session_start();
    if (mysqli_connect_error()) {
    ?>
        <script>
            alert("Database Connection Error Please Check !!! ");
        </script>
        <?php
    } 
    else 
    {
        if (isset($_REQUEST["btn_submit"])) 
        {
            $uname = $_REQUEST["username"];
            $pwd = $_REQUEST["password"];

            $q1 = "SELECT * FROM `admin` WHERE username='$uname' AND `password`='$pwd'";
            $result1 = mysqli_query($conn, $q1);
            if (mysqli_num_rows($result1) > 0)
            {
                 // session_start();
                 $_SESSION['admin'] = "Admin";
                 header("Location:AdminPannel/php_files/dashboard.php");
            }
            
            $q="SELECT * FROM doctors WHERE uname='$uname' AND `password`='$pwd'";
            $result=mysqli_query($conn,$q);

            if (mysqli_num_rows($result)>0)
            {
                $data=mysqli_fetch_assoc($result);
                $did=$data["doctor_id"];

                $_SESSION["doctor"]=$did;
                header("Location:DoctorPannel/php_files/dashboard.php");
            }
            else 
            {
                ?>
                <script>
                    alert("Check Username Or Password ");
                    window.location.href("Login.php");
                </script>
                <?php
            }
        }
    }

    ?>

    <?php

   if (!isset($_SESSION['admin']) || !isset($_SESSION['doctor'])) 
   {
   
    ?>

    <div class='maincontainer'>

        <div class="container">
            <div class='login_image'></div>

            <div class='loginform'>
                <h1 id='heading'>Health Care Login</h1>
                <form class='form ' action="Login.php" method="post">
                    <div class='form-floating mb-4'>
                        <input type='text' class='form-control' placeholder='' autocomplete="off" name="username" />
                        <label>Username</label>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type='password' class='form-control' placeholder='' autocomplete="off" name="password" />
                        <label>Password</label>
                    </div>

                    <div class='buttons mb-4'>
                        <input type="submit" class="btn btn-success col-4" value="Login" name="btn_submit" />
                        <input type="reset" class="btn btn-danger col-4" value="Reset" />
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
<?php
}
else
{
    if(isset($_SESSION['admin']))
    {
        header("Location:AdminPannel/dashboard.php");
    }
    if(isset($_SESSION['doctor']))
    {
        header("Location:DoctorPannel/php_files/dashboard.php");
    }

}
?>
</html>

