-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 25, 2025 at 06:35 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `healthcare`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(2) NOT NULL,
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `name`, `username`, `password`) VALUES
(1, 'Administrator', 'admin', 'admin'),
(2, 'Administrator2 ', 'admin2', 'admin2');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appoint_id` int(10) NOT NULL,
  `patient_id` int(10) NOT NULL,
  `doctor_id` int(10) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(10) NOT NULL,
  `reason` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'Approved'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appoint_id`, `patient_id`, `doctor_id`, `date`, `time`, `reason`, `status`) VALUES
(1, 1, 3, '2024-09-19', '10-11', 'fever', 'Approved'),
(2, 2, 1, '2024-09-18', '4-5', 'cold', 'Approved'),
(3, 4, 2, '2024-09-19', '9-10', 'stomach ache', 'Approved'),
(4, 2, 3, '2024-09-20', '11-12', 'fever and cold', 'Approved'),
(5, 3, 2, '2024-09-20', '7-8', 'headache and cold', 'Approved'),
(6, 2, 5, '2024-09-19', '4-5', 'jaundice', 'Disapprove'),
(7, 7, 3, '2024-09-21', '3-4', 'fever and cold', 'Approved'),
(8, 1, 5, '2024-09-21', '11-12', 'fever and stomach ache', 'Approved'),
(9, 2, 1, '2024-09-29', '3-4', 'qwerty', 'Approved'),
(10, 2, 1, '2024-10-21', '5-6', 'dfg', 'Approved'),
(11, 2, 2, '2024-10-22', '4-5', 'fever', 'Approved'),
(12, 8, 2, '2024-10-24', '7-8', '     ', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `doctor_id` int(10) NOT NULL,
  `doctor_name` varchar(20) NOT NULL,
  `profession` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `mno` decimal(10,0) NOT NULL,
  `email` varchar(30) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `image` varchar(200) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`doctor_id`, `doctor_name`, `profession`, `address`, `mno`, `email`, `uname`, `password`, `image`, `status`) VALUES
(1, 'Dr. Jonathan Ronan', 'Neuro Surgeons', '12 block gokul raw house, surat', 9712805566, 'jonathan@gmail.com', 'jonathan', 'jon12', 'doctor1.jpeg', 'Active'),
(2, 'Dr. Jane Ronan', 'Radiologists', '15 block gokul raw house, surat', 9712805544, 'jane@gmail.com', 'jane', 'jane123', 'doctor2.jpeg', 'Active'),
(3, 'Dr. pinkman janny', 'Plastic Surgeons', '380 block no, green resisdency, surat', 7125006020, 'pinkman@gmail.com', '    ', 'pinkman@12', 'doctor3.jpeg', 'Inactive'),
(4, 'Dr. Walter White', 'Arthopaedic Surgeons', '23 block, patel chembers, vesu, surat', 975210463, 'white@gmail.com', 'white', 'white12', 'doctor4.jpeg', 'Inactive'),
(5, 'Dr. Victor James', 'Urologists', '23 block, patel chembers, vesu, surat', 9510469653, 'james230@gmail.com', 'james', 'james12', 'doctor7.jpeg', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_id` int(10) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `feedback` varchar(300) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'Unshow'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedback_id`, `fname`, `email`, `feedback`, `status`) VALUES
(1, 'Mr. Shyam Chavda', 'shyam@gmail.com', 'thank you enough for the special excellent care you have provided and the unique gift to your patients also thanks to all Staff.', 'Show'),
(2, 'Mr. Jadav Dhruv', 'jadav@gmail.com', 'I visited last month, lost my purse their. Thankyou for the security team who coordinate with me and helped me in getting my purse.', 'Show'),
(3, 'Mr. Pankaj Kumar', 'pankaj@gmail.com', 'Doctors are explained & convinced the problem in a very good manner which helped in treatment & saved life. I will always be grateful. Regards', 'Show'),
(4, 'Mr. Sanjay Mehta', 'sanjay030@gmail.com', 'i recently book appointment from your website and as a developer i appreciate you and your group member you work very hard.', 'Unshow'),
(5, 'Mr. Williams James', 'william23@gmail.com', 'after you get past the fancy white interior you realize the services is super overpriced this guy charges way more than anyone else.', 'Unshow');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `patient_id` int(10) NOT NULL,
  `patient_name` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `age` int(10) NOT NULL,
  `mno` decimal(10,0) NOT NULL,
  `email` varchar(50) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`patient_id`, `patient_name`, `gender`, `age`, `mno`, `email`, `uname`, `password`) VALUES
(1, 'Sahil Shah', 'Male', 25, 9510479620, 'sahil003@gmail.com', 'sahil', 'sahil123'),
(2, 'Dev Raval', 'Male', 23, 8795421063, 'dev@gmail.com', 'dev', 'dev12'),
(3, 'Gayatri Lakhani', 'Female', 15, 9712805566, 'gayatri25@gmail.com', 'gayatri', 'gayatri2'),
(4, 'Pankaj Jikadra', 'Male', 21, 9758479620, 'pankaj@gmail.com', 'pankaj', 'pankaj21'),
(7, 'jayesh patel', 'Male', 28, 9780246312, 'jayesh@gmail.com', 'jayesh', 'jayesh12'),
(8, 'aa', 'Male', 33, 4646646464, 'abcd@Gmail.com', 'abcd', '123');

-- --------------------------------------------------------

--
-- Table structure for table `query`
--

CREATE TABLE `query` (
  `query_id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `query` varchar(100) NOT NULL,
  `response` varchar(20) NOT NULL DEFAULT 'Response'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `query`
--

INSERT INTO `query` (`query_id`, `name`, `email`, `query`, `response`) VALUES
(1, 'Jadav dhruv', 'jadav@gmail.com', 'i am very lucky that i am using this website', 'Sent'),
(2, 'pankaj', 'pankaj@gmail.com', 'good very good bro you are doing good i am appreciate that', 'Response'),
(5, 'karna', 'karna@gmail.com', 'i want to meet dentist will you suggest me any better doctor, i will be thankfull to you', 'Response');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appoint_id`),
  ADD KEY `doctor_id` (`doctor_id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`doctor_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `query`
--
ALTER TABLE `query`
  ADD PRIMARY KEY (`query_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appoint_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `doctor_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `patient_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `query`
--
ALTER TABLE `query`
  MODIFY `query_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`doctor_id`),
  ADD CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
