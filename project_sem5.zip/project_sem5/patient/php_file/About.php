<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/About.css">
    <link rel="website icon"href="../images/logo.png"/>
    <link rel="stylesheet" href="../styles/bootstrap.min.css">
    <title> About Us </title>
</head>

<body>
    <?php
        include_once('Navbar.php')
    ?>
    <div class='about'>
        <div class='image'></div>
        <div class='content'>
            <h6> ABOUT HEALTH CARE </h6>
            <h1> We Provide Finnest Patient's <span class='ca'> Care & Amenities </span> </h1>
            <h5> Embrace a world of comprehensive healthcare where your well-being takes center stage. At Meca,
                we're dedicated to providing you with personalized and compassionate medical services.</h5>

            <ul>
                <li> Seamless Care </li>
                <li> Warm and Welcoming Environment </li>
                <li> Comprehensive Care </li>
                <li> Expert Doctors </li>
                <li> Patient-Centered Care </li>
                <li> Cutting-Edge Technology </li>
                <li> Personalized Approach </li>
                <li> Positive Reviews </li>
            </ul>
            <h5>
                We are a private, independent practice constantly striving to provide excellence in personalized,
                compassionate care that is consistent, quality-driven and choice-conscious for all of our patients.
            </h5>
        </div>
    </div>

    <div class='text'>
        <h6> YOUR HEALTH IS OUR TOP PRIORITY </h6>
        <h2>
            Our track record speaks for itself. Many individuals have chosen
            <span class='header'> our medical center and have had positive,transformative experiences.</span>
        </h2>
    </div>

    <div class='ins'>
        <div class='left_ins'>
            <h5> Insurance </h5>
            <h1> Our Accepted <b> Insurance </b> </h1>
        </div>

        <div class='right_ins'>
            <div class='image_container'>
                <img alt='' src="../images/icici.jpeg" />
                <img alt='' src="../images/lic.png" />
                <img alt='' src="../images/sbi.jpg" />
                <img alt='' src="../images/reliance.png" />
            </div>
        </div>
    </div> <br>
</body>

</html>

<?php
include_once('Footer.php')
?>