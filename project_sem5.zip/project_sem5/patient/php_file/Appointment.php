<?php
$conn = mysqli_connect("localhost", "root", "", "healthcare");
$alert = false;
session_start();
if (!isset($_SESSION["patient"])) {
    header("location:Login.php");
}

if (!$conn) {
    echo "<script> alert('Database Not Connected') </script>";
}

if (isset($_REQUEST["btn_bookappointment"])) {

    $pname = $_REQUEST["patient_name"];
    $str = mysqli_query($conn, "SELECT * FROM patients WHERE patient_name='$pname'");
    $patientAll = mysqli_fetch_array($str);

    $ap_pid = $patientAll["patient_id"];
    $ap_docid = $_REQUEST["doctor"];
    $ap_dt = $_REQUEST["apoint_date"];
    $ap_tm = $_REQUEST["apoint_time"];
    $reason = $_REQUEST["reason"];

    $q = "INSERT INTO appointment (patient_id,doctor_id,`date`,`time`,reason) VALUES ($ap_pid,$ap_docid,'$ap_dt','$ap_tm','$reason')";
    mysqli_query($conn, $q);

    $alert = true;
}


$doctors_record = $conn->query("SELECT * FROM doctors WHERE `status` = 'Active'");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../styles/Appointment.css">
    <link rel="website icon" href="../images/logo.png" />
    <title> Appointment </title>
    <script>
        function validationForm() {
            var dsel = document.getElementById("D_Selection").value;
            var pdt = document.getElementById("P_Date").value;
            var ptime = document.getElementById("P_Time").value;
            var prs = document.getElementById("P_Reason").value;

            if (!dsel) {
                document.getElementById("doc").style.display = "block";
    
                setTimeout(() => {
                    document.getElementById("doc").style.display = "none";
                }, 1200);
    
                return false;
            }

            else if (!pdt) {
                document.getElementById("dt").style.display = "block";

                setTimeout(() => {
                    document.getElementById("dt").style.display = "none";
                }, 1200);

                return false;

            } 
            else if (!ptime) {
                document.getElementById("time").style.display = "block";

                setTimeout(() => {
                    document.getElementById("time").style.display = "none";
                }, 1200);

                return false;

            } 
            else if (!prs) {
                document.getElementById("rs").style.display = "block";

                setTimeout(() => {
                    document.getElementById("rs").style.display = "none";
                }, 1500);

                return false;

            } 
            
            else {
                return true;
            }
        }
    </script>
</head>

<body>

    <script>
        setTimeout(() => {
            document.getElementById("alert").style.display = "none";
        }, 1800)
    </script>

    <h1 class="text-center mb-4 my-3" id="hclr"> Keep <span class="hclr"> Calm </span></h1>
    <h4 class="text-center mb-4"> <span class="hclr"> Book </span> Your <span class="hclr"> Appointment </span> Now</h4>

    <div class="container" id="appointment">
        <?php
        if ($alert == true) {
            echo '<div id="alert" class="alert alert-primary text-center" role="alert">
            <h4 class="alert-heading">Success!</h4>
            <h5> Appointment Booked SuccessFully ! </h5>
            </div>';
        }  ?>

        <form method="post" class="form" onsubmit="return validationForm()">
            <img src="./logo.png" alt="" height="100" style="margin: 1vh 20vw;">
            <div class='form-floating mb-4'>
                <input type='text' class='form-control' id="P_Name" placeholder='' autocomplete="off" name="patient_name" value="<?php echo $_SESSION["patient"] ?>" />
                <label>Patient Name</label>
            </div>

            <div class='form-floating mb-4'>
                <select name="doctor" id="D_Selection" class="form-select">
                    <option value="">Select doctor</option>
                    <?php
                    while ($doctors = $doctors_record->fetch_assoc()) {
                    ?>
                        <option value="<?php echo $doctors["doctor_id"] ?>"><?php echo $doctors["doctor_name"] ?></option>
                    <?php
                    }
                    ?>
                </select>
                <label>Doctors</label>
                <span id="doc" style="color:red;display:none"> * Select Doctor First </span>
            </div>

            <div class='form-floating mb-4'>
                <input type='date' class='form-control' id="P_Date" placeholder='' autocomplete="off" name="apoint_date" />
                <label>Appointment Date</label>
                <span id="dt" style="color:red;display:none"> * Select Valid Date </span>
            </div>
            
            <div class='form-floating mb-4'>
                <select name="apoint_time" id="P_Time" class="form-select">
                    <option value="">Select Time</option>
                    <option value="9-10">9-10 AM</option>
                    <option value="10-11">10-11 AM</option>
                    <option value="11-12">11-12 AM</option>
                    <option value="3-4">3-4 PM</option>
                    <option value="4-5">4-5 PM</option>
                    <option value="5-6">5-6 PM</option>
                    <option value="7-8">7-8 PM</option>
                    <option value="8-9">8-9 PM</option>
                </select>
                <label>Appointment Time</label>
                <span id="time" style="color:red;display:none"> * Select Valid Time </span>
            </div>
            
            <div class='form-floating mb-4'>
                <input type='text' class='form-control' id="P_Reason" placeholder='' autocomplete="off" name="reason" />
                <label>Reason Of Appointment</label>
                <span id="rs" style="color:red;display:none"> * Tell Reason To Meet With Us </span>
            </div>
            
            <div class="mb-4 buttons">
                <input type="submit" value="Book Appointment" name="btn_bookappointment" class="btn btn-success mb-4" />
                <input type="reset" value="Reset" name="btn_reset" class="btn btn-danger mx-2 mb-4" />
            </div>
        </form>
    </div>
    <script>
        const today = new Date().toISOString().split('T')[0];
        document.getElementById("P_Date").setAttribute("min", today);
        // console.log(today);
    </script>
</body>

</html>