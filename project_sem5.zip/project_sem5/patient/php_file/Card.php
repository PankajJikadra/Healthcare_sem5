<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/Card.css">
    <link rel="website icon"href="../images/logo.png"/>
</head>

<body>
    <div class='cardContainer'>
        <div class='mission' id='card'>
            <img alt='' src="../images/bindu.png" class='bindu' />
            <h5> OUR MISSION </h5>
            <p> Our mission is to care for our patients and their families when it matters most. </p>
        </div>

        <div class='vision' id='card'>
            <img alt='' src="../images/bindu.png" class='bindu' />
            <h5> OUR VISION </h5>
            <p> Our vision is to invent the future of health care technologies. </p>
        </div>

        <div class='values' id='card'>
            <img alt='' src="../images/bindu.png" class='bindu' />
            <h5> OUR VALUES </h5>
            <p> Our values are: excellence, collaboration, accountability, respect and engagement. </p>
        </div>
    </div>
</body>

</html>