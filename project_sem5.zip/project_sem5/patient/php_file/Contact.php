<?php
include_once('Navbar.php')
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/Contact.css" type="text/css">
    <link rel="website icon" href="../images/logo.png" />
    <link rel="stylesheet" href="./bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

    <title> Contact Us </title>
    <script>
        function validationQuery() {
            var name = document.getElementById("name").value;
            var email = document.getElementById("email").value;
            var query = document.getElementById("query").value;

            if (!name) {
                document.getElementById("nmval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("nmval").style.display = "none";
                }, 1200);

                return false;
            } else if (!email) {
                document.getElementById("emval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("emval").style.display = "none";
                }, 1200);

                return false;
            } else if (!query) {
                document.getElementById("qval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("qval").style.display = "none";
                }, 1500);

                return false;
            } else {
                return true;
            }
        }
    </script>
</head>

<body>
    <div class='contactImage'>
        <div class='contactText'>
            <h1> THE BEST DOCTOR <br> <span id='qutoes'> GIVES THE LEAST MEDICINES </span></h1>
        </div>
    </div>

    <div id="container" class="my-5 mb-2">
        <div class="card" id="location">
            <h3> OUR LOCATIONS </h3>
            <p>Health Care Hospital,Katargam,Surat</p>
        </div>

        <div class="card" id="contact">
            <h3> CONTACT WITH US </h3>
            <p>Call : +91 9510469686 , 0261 321654</p>
        </div>

        <div class="card" id="hours">
            <h3> VISITING HOURS </h3>
            <p>Sunday : 9:00AM-2:00PM</p>
            <p>Monday-Saturday : 10:00AM-4:00PM</p>
        </div>
    </div>

    <?php
    $conn = mysqli_connect("localhost", "root", "", "healthcare");
    $alert = false;

    if (!$conn) {
        echo "<script> alert('database not connected'); </script>";
    }

    if (isset($_REQUEST["btn_msg"])) {
        $name = $_REQUEST["name"];
        $email = $_REQUEST["email"];
        $query = $_REQUEST["query"];

        $q = "INSERT INTO query(`name`,`email`,query) VALUES ('$name','$email','$query')";
        mysqli_query($conn, $q);
        $alert = true;
    }

    ?>

    <div class="feedback mb-4 my-4" id="feedback_block">
        <h1 class="text-center"> Hospital are about <span id="feed"> Healing. </span> </h1>
        <h3 class="text-center"> Get in <span id="feed"> Touch. </span> </h3>

        <div class="feedback-form my-4">
            <form method="post" class="form" onsubmit="return validationQuery()">
                <input type="hidden" name="submitted" value="true">
                <div class="form-floating mb-4">
                    <input type="text" class="form-control" name="name" id="name" placeholder="">
                    <label for="floatingInput">Name</label>
                    <span id="nmval" style="color:red;display:none;"> * Required </span>
                </div>
                <div class="form-floating mb-4">
                    <input type="email" class="form-control" name="email" id="email" placeholder="">
                    <label for="floatingInput">Email</label>
                    <span id="emval" style="color:red;display:none;"> * Email is Mandatory </span>
                </div>
                <div class="form-floating">
                    <textarea class="form-control" name="query" placeholder="" id="query" style="height: 150px;resize:none;"></textarea>
                    <label for="floatingTextarea2">Write if you have any query</label>
                    <span id="qval" style="color:red;display:none;"> * Tell about your vision to grow more </span>
                </div>

                <div class="btn-group my-4 mx-5">
                    <button type="submit" class="btn btn-success" name="btn_msg" id="liveToastBtn"> Send Your Query </button>
                    <button type="reset" class="btn btn-danger mx-4"> Clear All </button>
                </div>
            </form>
        </div>


        <div class="toast-container position-fixed bottom-0 end-0 p-3">
            <div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header">
                    <img src="../images/logo.png" class="rounded me-2" alt="" height="50">
                    <strong class="me-auto">Success</strong>
                    <small>1 mins ago</small>
                    <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    Thank you! We will response as soon as possible
                </div>
            </div>
        </div>

    </div>

    <?php
    if ($alert == true) { ?>
        <script>
            const toastLiveExample = document.getElementById('liveToast')
            const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample)
            toastBootstrap.show()
        </script>

    <?php } ?>
</body>

</html>

<?php
include_once('Footer.php')
?>