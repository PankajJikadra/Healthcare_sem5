<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <title>Healthcare</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1" />
  <!-- Link Swiper's CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
    crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
  <link rel="stylesheet" href="../styles/Doctors.css" type="text/css">
  <link rel="website icon"href="../images/logo.png"/>

</head>

<body>

  <?php
  $conn = mysqli_connect("localhost", "root", "", "healthcare");

  $query = "SELECT * FROM doctors WHERE `status`= 'Active' ";
  $doctors_data = mysqli_query($conn, $query);
  ?>

  <div class="maincontainer">
    <div class='heading'>
      <h6> FIND HEALTH PROFESSIONALS</h6>
      <h1> Find Your Desired <span class='change_color'> Health <br>Professionals </span> </h1>
    </div>

    <div class="doctors_container">
      <!-- Swiper -->
      <div class="swiper mySwiper">
        <div class="swiper-wrapper">
          <?php
          while ($data = mysqli_fetch_assoc($doctors_data)) {
          ?>
            <div class="swiper-slide">
              <div class="doctor">
                <div class="img">
                  <img src="../../Login/AdminPannel/doctor_image/<?php echo $data["image"] ?>" alt="DOCOTR" class="doctor_image">
                </div>
                <div class="details">
                  <h4><?php echo $data["doctor_name"] ?></h4>
                  <p> <?php echo $data["profession"] ?> </p>
                  <a href="./Appointment.php">
                    <button class="btn btn-outline-danger">Book Appointment</button>
                  </a>
                </div>
              </div>
            </div>
          <?php
          }
          ?>
        </div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
        <div class="swiper-pagination" id="pagination_dots"></div>
      </div>
    </div>
  </div>

  <!-- Swiper JS -->
  <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

  <!-- Initialize Swiper -->
  <script>
    var swiper = new Swiper(".mySwiper", {
      slidesPerView: 3,
      spaceBetween: 30,
      freeMode: true,
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      }
    });
  </script>
</body>

</html>