<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/Facility.css">
    <link rel="website icon"href="../images/logo.png"/>
</head>

<body>
    <div class='services'>
        <h1> We Provide Total <span class='heading'> Health Care </span> Solution </h1>
        <h3> Our <span class='heading'> Facilities </span> & <span class='heading'> Services </span> </h3>
    </div>
    <div class="facility">
        <div class="image">
            <img src="../images/ambu.jpeg" alt='Facility_Images' />
            <div class='details'>
                <h4> Ambulance Services 24/7 </h4>
            </div>
        </div>
        <div class="image">
            <img src="../images/eye.jpg" alt='Facility_Images' />
            <div class='details'>
                <h4> Free Eye Test </h4>
            </div>
        </div>
        <div class="image"> 
            <img src="../images/emergency.jpg" alt='Facility_Images' />
            <div class='details'>
                <h4> Emergency Ward </h4>
            </div>
        </div>
        <div class="image">
            <img src="../images/icu.jpg" alt='Facility_Images' />
            <div class='details'>
                <h4> High-Technology Equipment </h4>
            </div>
        </div>
        <div class="image">
            <img src="../images/laboratory.jpg" alt='Facility_Images' />
            <div class='details'>
                <h4> Blood Laboratory </h4>
            </div>
        </div>
        <div class="image">
            <img src="../images/mri.jpg" alt='Facility_Images' />
            <div class='details'>
                <h4> MRI & CT Scan Machines </h4>
            </div>
        </div>
    </div> <br></br>
</body>

</html>