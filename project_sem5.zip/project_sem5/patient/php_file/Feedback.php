<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/Feedback.css">
    <link rel="website icon" href="../images/logo.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
    <script>
        function validationFeedback() {
            var fname = document.getElementById("fname").value;
            var email = document.getElementById("email").value;
            var feedback = document.getElementById("feedback").value;


            if (!fname) {
                document.getElementById("fval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("fval").style.display = "none";
                }, 1200);

                return false;

            } else if (!email) {
                document.getElementById("emval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("emval").style.display = "none";
                }, 1200);

                return false;

            } else if (!feedback) {
                document.getElementById("fedval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("fedval").style.display = "none";
                }, 1500);

                return false;
            } else {
                return true;
            }
        }
    </script>
</head>

<body>
    <?php
    $conn = mysqli_connect("localhost", "root", "", "healthcare");
    $alert = false;

    if (!$conn) {
        echo "<script> alert('database not connected'); </script>";
    }

    if (isset($_REQUEST["btn_feedback"])) {
        $fname = $_REQUEST["fname"];
        $email = $_REQUEST["email"];
        $feedback = $_REQUEST["feedback"];

        $q = "INSERT INTO feedback VALUES ('','$fname','$email','$feedback','Unshow')";
        mysqli_query($conn, $q);
        $alert = true;
    }

    ?>

    <div class="feedback" id="feedback_block">
        <h1 class="text-center"> We all need people who will give us <span id="feed"> feedback. </span> </h1>
        <h3 class="text-center"> That's how <span id="feed"> we improve. </span> </h3>

        <div class="feedback-form my-4">
            <form method="post" class="form" onsubmit="return validationFeedback()">
                <input type="hidden" name="submitted" value="true">
                <div class="form-floating mb-4">
                    <input type="text" class="form-control" name="fname" placeholder="" id="fname">
                    <label for="floatingInput">Full Name</label>
                    <span id="fval" style="color:red;display:none;"> * Required </span>
                </div>
                <div class="form-floating mb-4">    
                    <input type="email" class="form-control" name="email" placeholder="" id="email">
                    <label for="floatingInput">Email</label>
                    <span id="emval" style="color:red;display:none;"> * Email is Mandatory </span>
                </div>
                <div class="form-floating">
                    <textarea class="form-control" name="feedback" placeholder="" id="feedback" style="height: 150px;resize:none;"></textarea>
                    <label for="floatingTextarea2">Tell us what you think</label>
                    <span id="fedval" style="color:red;display:none;"> * write your thoughts to improve us more</span>
                </div>

                <div class="btn-group my-4 mx-5">
                    <button type="submit" class="btn btn-success" name="btn_feedback" id="liveToastBtn"> Send Feedback </button>
                    <button type="reset" class="btn btn-danger mx-4"> Clear All </button>
                </div>
            </form>
        </div>


        <div class="toast-container position-fixed bottom-0 end-0 p-3">
            <div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header">
                    <img src="../images/logo.png" class="rounded me-2" alt="" height="50">
                    <strong class="me-auto">Success</strong>
                    <small>1 mins ago</small>
                    <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    Thank you! feedback sent
                </div>
            </div>
        </div>

    </div>

    <?php
    if ($alert == true) { ?>
        <script>
            const toastLiveExample = document.getElementById('liveToast')
            const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample)
            toastBootstrap.show()
        </script>

    <?php } ?>
</body>

</html>