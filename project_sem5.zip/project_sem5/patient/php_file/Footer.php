<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/Footer.css">
    <link rel="website icon"href="../images/logo.png"/>
</head>

<body>
    <div class='footer'>
        <div class='first_footer'>
            <img alt='' src="../images/logo.png" />
            <h5> Location : HealthCare Hospital,Katargam,Surat </h5>
            <h5> Visiting Hours : 10:00 AM to 4:00 PM </h5>
        </div>
        <div class='first_footer'>
            <h3> Community </h3>
            <div class='para'>
                <p> Doctors </p>
                <p> Testimonials </p>
                <p> FAQs </p>
                <p> Blog </p>
                <p> Site Map </p>
            </div>
        </div>
        <div class='first_footer'>
            <h3> About </h3>
            <div class='para'>
                <p> Careers </p>
                <p> Education </p>
                <p> About Us </p>
                <p> Areas Of Care </p>
                <p> Volunteers </p>
            </div>
        </div>
        <div class='first_footer'>
            <h3> Support </h3>
            <div class='para'>
                <p> Visitor Information </p>
                <p> Emergency Care </p>
                <p> Donate </p>
                <p> Online Services </p>
                <p> Pay Your Bills </p>
            </div>
        </div>
        <div class='first_footer'>
            <h3> Trust & Legal </h3>
            <div class='para'>
                <p> Terms & Conditions </p>
                <p> Privacy Policy </p>
                <p> Hospital Stay </p>
            </div> <br></br>

            <h3> Social Media </h3>
            <div class='s_icon'>
                <img src="../images/facebook.svg" alt="FaceBook" width="30px">
                <img src="../images/instagram.svg" alt="Instragram" width="30px">
                <img src="../images/twitter-x.svg" alt="Twitter" width="30px">
                <img src="../images/whatsapp.svg" alt="Whatsapp" width="30px">
            </div>
        </div>
    </div>

    <div class='footer_bottom'>
        <h5> &copy; HealthCare All Rights Reserved 2024 Inc. </h5>
    </div>
</body>

</html>