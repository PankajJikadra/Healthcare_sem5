<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/Herosection.css">
    
</head>
<body>
    <div class='herosection'>
        <div class='hero_con'>
             <h6> Team Health Care </h6> 
             <h2> A Dedicated <span> Doctors </span> </h2> <h3> You Can <span> Trust </span></h3>
             <h4> We Are Different To  Protect Your Health </h4>
             <ul>
                <li> Not Just Better Care,But A Better Experience </li>
                <li> Serving All People Through Exemplary Care </li>
                <li> Speciality Medicine With Compassion and Care  </li>
             </ul>
        </div>
  </div>
</body>
</html>