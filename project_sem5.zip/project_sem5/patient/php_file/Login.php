<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../styles/Login.css" type="text/css" />
    <link rel="website icon"href="../images/logo.png"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <?php
    $conn = mysqli_connect("localhost", "root", "", "healthcare");
    $alert = false;
    $msg = "";

    session_start();
    if (mysqli_connect_error()) {
    ?>
        <script>
            alert("Database Connection Error Please Check !!! 😮‍💨 ");
        </script>
    <?php
    } else {
        if (isset($_REQUEST["btn_submit"])) 
        {
            $uname = $_REQUEST["uname"];
            $password = $_REQUEST["password"];

            $result = mysqli_query($conn, "SELECT * FROM patients WHERE uname = '$uname'");
            if (mysqli_num_rows($result) == 1) {
                $row = mysqli_fetch_array($result);
                if ($row["password"] == $password) {
                    session_start();
                    $_SESSION["patient"] = $row["patient_name"];
                    header("location:index.php");
                } else {
                    $alert = true;
                    $msg = "Check Password !";
                }
            }
            else
            {
                $alert=true;
                $msg="Check Username !";    
            }
            
        }
    }
    ?>

    <div class='maincontainer'>

        <div class="container">
            <div class='login_image'></div>

            <div class='loginform'>
                <?php
                if ($alert == true) {
                    echo '<div class="alert alert-danger" id="alert" role="alert">
                    '.$msg.' </div>';
                }
                ?>

                <script>
        
                    setTimeout(()=>{
                        document.getElementById("alert").style.display="none";
                    },2000);

                </script>
                
                <img src="../images/logo.png" alt="" height="80">
                <h1 id='heading'>Login</h1>
                <form class='form' action="Login.php" method="post">
                    <div class='form-floating mb-4'>
                        <input type='text' class='form-control' placeholder='' autocomplete="off" name="uname" />
                        <label>Username</label>
                    </div>

                    <div class='form-floating mb-4'>
                        <input type='password' class='form-control' placeholder='' autocomplete="off" name="password" />
                        <label>Password</label>
                    </div>

                    <div class='buttons mb-4'>
                        <input type="submit" class="btn btn-primary col-8" value="Login" name="btn_submit" />
                    </div>

                    <div class="register_link">
                        <h6> Don't have an account ?
                            <a href="./Register.php"> Register </a>
                        </h6>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>