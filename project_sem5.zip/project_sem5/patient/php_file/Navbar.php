<?php
session_start();
if (isset($_REQUEST["logout"])) {
    session_unset();
    session_destroy();
    header("Location:Login.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/Navbar.css">
    <link rel="stylesheet" href="../styles/bootstrap.min.css" type="text/css">
    <link rel="website icon" href="../images/logo.png" />
</head>

<body>
    <nav class="navbar" id="nav">
        <div class="logo">
            <img src="../images/logo.png" alt="Logo" />
            <h3 id='h3'>Health Care</h3>
        </div>

        <ul class='ul'>
            <li>
                <a href="index.php" class='link'>Home</a>
            </li>
            <li>
                <a href="About.php" class='link'>About Us</a>
            </li>
            <li>
                <a href="Contact.php" class='link'>Contact Us</a>
            </li>
            <li id="btns">
                <a href="./Appointment.php">
                    <button class="btn btn-outline-danger" id="emergencyButton" title='Book Appointment'>
                        <img src="../images/alarm.svg" alt="" height="25px" id="icon">
                        Emergency
                    </button>
                </a>
                <?php
                if (!isset($_SESSION["patient"])) {
                ?>
            <li>
                <a href="./Login.php">
                    <button class="btn btn-outline-primary mx-5" id="loginButton" title='Login'>
                        <img src="../images/login.png" alt="" height="25" id="icon">
                        Login
                    </button>
                </a>
            </li>
        <?php } ?>

        <?php
        if (isset($_SESSION["patient"])) {
        ?>
            <li>
                <div id="patient_name">
                    <img src="../images/admin.svg" alt="" height="25" id="patientIcon">
                    <h5 class="text-center" id="pname">
                        <?php
                        echo $_SESSION["patient"];
                        ?>
                    </h5>
                </div>
            </li>
        <?php } ?>

        <?php
        if (isset($_SESSION["patient"])) {
        ?>
            <li>
                <a href="Navbar.php?logout=true" id="logout">

                    <button class="btn btn-danger" name="logout" id="logout_btn">
                    <img src="../images/right-from-bracket-solid.svg" style="filter:invert(1);" alt="" height="15px" id="logoutIcon">Logout </button>
                </a>
            </li>
        <?php
        } ?>

        </li>
        </ul>
    </nav>

</body>

</html>