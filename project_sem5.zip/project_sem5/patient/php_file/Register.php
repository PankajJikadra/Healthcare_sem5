<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="../styles/Register.css" type="text/css" />
    <link rel="website icon" href="../images/logo.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script>
        function validationRegister() {
            var pname = document.getElementById("patient_name").value;
            var age = document.getElementById("age").value;
            var mno = document.getElementById("mno").value;
            var email = document.getElementById("email").value;
            var uname = document.getElementById("uname").value;
            var password = document.getElementById("password").value;

            if (!pname) {
                document.getElementById("pnameval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("pnameval").style.display = "none";
                }, 1200);

                return false;
            } else if (!age) {
                document.getElementById("ageval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("ageval").style.display = "none";
                }, 1200);

                return false;
            } else if (!mno) {
                document.getElementById("mnoval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("mnoval").style.display = "none";
                }, 1200);

                return false;
            } else if (!email) {
                document.getElementById("emval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("emval").style.display = "none";
                }, 1200);

                return false;
            } else if (!uname) {
                document.getElementById("uval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("uval").style.display = "none";
                }, 1200);

                return false;
            } else if (!password) {
                document.getElementById("passval").style.display = "block";

                setTimeout(() => {
                    document.getElementById("passval").style.display = "none";
                }, 1200);

                return false;
            } else {
                return true;
            }
        }
    </script>
</head>

<body>
    <?php
    $conn = mysqli_connect("localhost", "root", "", "healthcare");
    $Alert = false;
    session_start();
    if (mysqli_connect_error()) {
    ?>
        <script>
            alert("Database Connection Error Please Check !!!  ");
        </script>
    <?php
    } else {
        if (isset($_REQUEST["btn_submit"])) {
            $pname = $_REQUEST["patient_name"];
            $gender = $_REQUEST["gender"];
            $age = $_REQUEST["age"];
            $mno = $_REQUEST["mno"];
            $email = $_REQUEST["email"];
            $uname = $_REQUEST["uname"];
            $password = $_REQUEST["password"];

            $result = mysqli_query($conn, "SELECT * FROM patients WHERE uname = '$uname'");

            if (mysqli_num_rows($result) > 0) {
                $Alert = true;
            } else {
                $query = "INSERT INTO patients VALUES('','$pname','$gender',$age,$mno,'$email','$uname','$password')";
                mysqli_query($conn, $query);
                header("location:Login.php");
            }
        }
    }
    ?>

    <div class='maincontainer'>

        <div class="container">
            <div class='register_image'></div>

            <div class='registerform'>
                <?php
                if ($Alert == true) {
                    echo '<div class="alert alert-danger" id="alert" role="alert"> Patient Alredy Exists </div>';
                }
                ?>
                <script>
                    setTimeout(() => {
                        document.getElementById("alert").style.display = "none";
                    }, 1500);
                </script>

                <img src="../images/logo.png" alt="" height="80">
                <h1 id='heading'>Register</h1>
                <form class='form' action="Register.php" method="post" onsubmit="return validationRegister()">
                    <div class="dflex">
                        <div class="form-floating mb-2">
                            <input type="text" class="form-control mb-1" placeholder="" name="patient_name" id="patient_name">
                            <label for="floatingInput">Patient Name</label>
                            <span class="my-1" id="pnameval" style="color:red;background-color:white;border-radius:3px;padding:0 8px;display:none;"> * Patient Name Required </span>
                        </div>

                        <div class="dflex mb-2 mx-3">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender" value="Male" checked>
                                <label class="form-check-label" for="flexRadioDefault1"> Male </label>
                            </div>

                            <div class="form-check mx-2">
                                <input class="form-check-input" type="radio" name="gender" value="Female">
                                <label class="form-check-label" for="flexRadioDefault1"> Female </label>
                            </div>
                        </div>
                    </div>

                    <div class="dflex">

                        <div class='form-floating mb-2'>
                            <input type='tel' class='form-control' maxlength="3" oninput="this.value = this.value.replace(/\D/, '');" placeholder='' autocomplete="off" name="age" id="age" />
                            <label>Age</label>
                            <span class="my-1" id="ageval" style="color:red;background-color:white;border-radius:3px;padding:0 8px;display:none;"> * Age Required </span>
                        </div>

                        <div class='form-floating mb-2 mx-3'>
                            <input type='tel' class='form-control' oninput="this.value = this.value.replace(/[^0-9]/, '');" maxlength="10" placeholder='' autocomplete="off" name="mno" id="mno" />
                            <label>Moblie Number</label>
                            <span class="my-1" id="mnoval" style="color:red;background-color:white;border-radius:3px;padding:0 8px;display:none;"> * Moblie Required </span>
                        </div>
                    </div>

                    <div class='form-floating mb-2'>
                        <input type='email' class='form-control' placeholder='' autocomplete="off" name="email" id="email" />
                        <label>Email</label>
                        <span class="my-1" id="emval" style="color:red;background-color:white;border-radius:3px;padding:0 8px;display:none;"> * Email Required </span>
                    </div>

                    <div class="dflex">
                        <div class='form-floating mb-2'>
                            <input type='text' class='form-control' placeholder='' autocomplete="off" name="uname" id="uname" />
                            <label>Username</label>
                            <span class="my-1" id="uval" style="color:red;background-color:white;border-radius:3px;padding:0 8px;display:none;"> * Username Required </span>
                        </div>

                        <div class='form-floating mb-2 mx-3'>
                            <input type='password' maxlength="8" class='form-control' placeholder='' autocomplete="off" name="password" id="password" />
                            <label>Password</label>
                            <span class="my-1" id="passval" style="color:red;background-color:white;border-radius:3px;padding:0 8px;display:none;"> * password can't blank </span>
                            <span id="passval1" style="color:red;background-color:white;border-radius:3px;padding:0 8px;display:none;"> * * password Must 8 characters long </span>
                        </div>
                    </div>

                    <div class='buttons mb-2'>
                        <input type="submit" class="btn btn-primary col-8" value="Register" name="btn_submit" />
                    </div>

                    <div class="register_link">
                        <h6> Already an account ?
                            <a href="./Login.php"> Login </a>
                        </h6>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>