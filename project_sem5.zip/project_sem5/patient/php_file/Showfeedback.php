<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Healthcare</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
        crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="../styles/Showfeedbackcss.css" type="text/css">
    <link rel="website icon"href="../images/logo.png"/>


</head>

<body>

    <?php
    $conn = mysqli_connect("localhost", "root", "", "healthcare");

    $query = "SELECT * FROM feedback WHERE `status`='Show'";
    $feedback_data = mysqli_query($conn, $query);
    ?>


    <div class="feedback_container">
        <h1 class="text-center mb-5"> Our Past <span id="fd"> Best Feedback </span></h1>
        <div class="swiper mySwiper" id="swiper">
            <div class="swiper-wrapper">
                <?php
                while ($data = mysqli_fetch_assoc($feedback_data)) {
                ?>
                    <div class="swiper-slide">
                        <div class="card">
                            <h5 class="text-center my-4 mx-3" style="line-height:30px;"> <?php echo $data["feedback"] ?></h5>
                            <img src="../images/admin.svg" class="my-4" alt="" height="50" width="50" id="feedbackicon"/>
                            <h5 class="text-center my-3 text-primary"><?php echo $data["fname"] ?></h5>
                        </div>
                    </div>
                <?php
                }
                ?>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-pagination" id="pagination_dots"></div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <script>
        var swiper = new Swiper(".mySwiper", {
            slidesPerView: 3,
            spaceBetween: 30,
            freeMode: true,
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
            },
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            }
        });
    </script>
</body>

</html>