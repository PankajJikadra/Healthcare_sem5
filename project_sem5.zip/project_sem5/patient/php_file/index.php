<?php
  include_once('./Navbar.php');
  include_once('./Herosection.php');
  include_once('./Doctors.php');
  include_once('./Facility.php');
  include_once('./Card.php');
  include_once('./Feedback.php');
  include_once('./Showfeedback.php');
  include_once('./Footer.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> Health Care </title>
  <link rel="website icon" href="../images/logo.png"/>
  <link rel="stylesheet" href="../styles/bootstrap.min.css" type="text/css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" 
  integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>

</body>
</html>